import tensorqtl
tensorqtl.main()
